﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml;

namespace Xml_ile_Meteorolojiden_Veri_Cekme
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            string url = @"https://www.mgm.gov.tr/FTPDATA/analiz/sonSOA.xml";

            WebClient wc = new WebClient();

            string xmlData = wc.DownloadString(url);
            XmlDocument xDoc = new XmlDocument();
            xDoc.LoadXml(xmlData);

            XmlNodeList sehirler = xDoc.DocumentElement.SelectNodes("sehirler");

            foreach (XmlNode s in sehirler)
            {
                try
                {
                    Sehirler city = new Sehirler()
                    {
                        Bolge = s.SelectSingleNode("Bolge").InnerText,
                        Peryot = s.SelectSingleNode("Peryot").InnerText,
                        ili = s.SelectSingleNode("ili").InnerText,
                        Merkez = s.SelectSingleNode("Merkez").InnerText,
                        Durum = s.SelectSingleNode("Durum").InnerText,
                        Mak = s.SelectSingleNode("Mak").InnerText,
                        Min = s.SelectSingleNode("Min").InnerText,
                        SehirIkon = s.SelectSingleNode("SehirIkon").InnerText,
                    };
                    cbIller.Items.Add(city);
                }
                catch (Exception)
                {
                    return;
                }
            }
            
        }

        private void btnVeriCek_Click(object sender, EventArgs e)
        {
            if (cbIller.SelectedItem != null)
            {
                Sehirler city = cbIller.SelectedItem as Sehirler;

                txtBolge.Text = city.Bolge;
                txtDurum.Text = city.Durum;
                txtIl.Text = city.ili;
                txtMax.Text = city.Mak;
                txtMerkez.Text = city.Merkez;
                txtMin.Text = city.Min;
                txtPeryot.Text = city.Peryot;
            }
            else
            {
                MessageBox.Show("Lütfen İl Seçiniz !!!");
            }
        }
    }
}
