﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Xml_ile_Meteorolojiden_Veri_Cekme
{
    public class Sehirler
    {
        public string Bolge { get; set; }
        public string Peryot { get; set; }
        public string ili { get; set; }
        public string Merkez { get; set; }
        public string Durum { get; set; }
        public string Mak { get; set; }
        public string Min { get; set; }
        public string SehirIkon { get; set; }

        public override string ToString()
        {
            return this.ili;
        }
    }
}
